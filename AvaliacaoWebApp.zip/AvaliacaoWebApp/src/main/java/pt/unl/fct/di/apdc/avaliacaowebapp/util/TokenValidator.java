package pt.unl.fct.di.apdc.avaliacaowebapp.util;

public class TokenValidator {

	public TokenValidator() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public TokenValidator(AuthToken token) {
		
	}
	
	
	
	
	

}
